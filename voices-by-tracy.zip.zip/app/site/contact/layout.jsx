
const RootLayout = ({ children }) => {
    return (
        <section>{children}</section>
    )
}

export default RootLayout