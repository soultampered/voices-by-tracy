
const SiteLayout = ({ children }) => {
    return (
        <section>{children}</section>
    )
}

export default SiteLayout